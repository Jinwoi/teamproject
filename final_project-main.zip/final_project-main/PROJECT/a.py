from random import *
print('{:03d}'.format(randint(0,1000)))